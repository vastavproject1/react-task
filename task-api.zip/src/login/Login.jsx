import axios from "axios";
import React, { useState, useEffect } from "react";
import "../App.css";
import { Route, Routes, Navigate, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
//   toast.configure();

const Login = () => {
  useEffect(() => {
    if (localStorage.getItem("login_token")) {
      navigate("/userdata");
      // console.log("have data");
    }
  }, []);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, seterr] = useState(false);

  const navigate = useNavigate();

  const handleOnSubmit = async (e) => {
    e.preventDefault();

    if (email && password) {
      // const loginresponse = await axios.post("http://192.168.1.192:3000/login",
      // {
      // email:email,
      // password:password}
      // )
      // console.log(loginresponse,"loginresponse");
      // const token = localStorage.setItem("login_token", loginresponse.data.token);
      // navigate("/userdata");
      // console.log(loginresponse.data)
      await axios
        .post("http://192.168.1.192:3000/login", {
          email: email,
          password: password,
        })
        .then((response) => {
          toast.success("Login successfully!",{autoClose: 1000});
          const token = localStorage.setItem(
            "login_token",
            response.data.token
          );
          setTimeout(() => {
            navigate("/userdata");
          }, 1000);

          //   navigate("/userdata");
        })
        .catch((err) => {
          toast.error("Invalid Credential!",{autoClose: 500});
        });
    }
    if (email.length == 0 || password.length == 0) {
      seterr(true);
    }
  };

  return (
    <>
      <h4 className="login-titlle">Login page</h4>
      <form className="login-form">
        <lable className="login-lable"> Enter your Email</lable>
        <input
          type="email"
          className="input-field"
          onChange={(e) => setEmail(e.target.value)}
        />
        {err && email.length <= 0 ? (
          <span style={{ color: "red" }}>Email is required</span>
        ) : (
          ""
        )}
        <lable className="login-lable">Enter your password</lable>
        <input
          type="password"
          className="input-field"
          onChange={(e) => setPassword(e.target.value)}
        />
        {err && password.length <= 0 ? (
          <span style={{ color: "red" }}>Password is required</span>
        ) : (
          ""
        )}

        <a href="">Forgot password?</a>
        <label className="login-lable"></label>
        <input
          type="submit"
          value="Login"
          className="input-field"
          onClick={handleOnSubmit}
        />
        <ToastContainer autoClose={2000} />
      </form>
    </>
  );
};

export default Login;
