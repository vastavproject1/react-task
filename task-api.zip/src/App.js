import React from 'react'
import Userdata from './component/Userdata'
import Login from './login/Login'
import {
  Route,
  Routes,
  Navigate,
  useNavigate,
  BrowserRouter,
} from "react-router-dom";
import Protected from './Protected'

const App = () => {
  return (
    

    <>
    <BrowserRouter>
    <Routes>
    <Route path="/" element={<Login />} />
    <Route
            path="/userdata"
            element={
                <Protected Cmp ={Userdata} />
               
            }/>
    
    {/* <Route path="/userdata" element={<Userdata />} /> */}
    
    </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
