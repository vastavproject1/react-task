import React from 'react'

const DeleteUser = (props) => {

// console.log(props)
const handleOnDelete = () =>{
    console.log(props.id, "delete_id")
    // console.log("delete");
}

  return (
    <div>
        <button onClick={handleOnDelete}>Delete2</button>
    </div>
  )
}

export default DeleteUser