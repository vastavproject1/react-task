import React, { useEffect, useState } from "react";
import "./style.css";
import axios from "axios";
import AddUser from "./AddUser";
import DeleteUser from "./DeleteUser";
import EditUser from "./EditUser";
import { notification, Popconfirm } from "antd";
import "antd/dist/antd.css";
import {
  Route,
  Routes,
  Navigate,
  useNavigate
} from 'react-router-dom'
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Image } from "react-bootstrap";



const Userdata = () => {

  const [userdata, setUserData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const[getAddData, setAddData] = useState([]);
  const [token,settoken] = useState(""); 
  const navigate = useNavigate();
// useEffect(()=>{
//   const localtoken = (localStorage.getItem('login_token'));
//   // console.log("logintoken",localtoken);
//   settoken(localtoken);
// })

// console.log(token,"token")






  // deltee popup
  const [popup, setPopup] = useState({
    show: false, // initial values set to false and null
    id: null,
  });

  // let header_token = "Bearer" +token;
  // console.log("header_token",header_token)
   useEffect(() => {

   console.log("effect run");

    const getData = async () =>  {
      
      try {        
        let header_token = `Bearer ${localStorage.getItem('login_token')}` ;
        const response = await axios.get("http://192.168.1.192:3000/user",{
          headers:{Authorization:header_token}
        });
        // console.log("header_token", header_token)
        // const response = await axios.get("http://192.168.1.192:3000/user");
        setUserData(response.data)
        setError(null);
        console.log(response.data,"response")
      } catch (err) {
        setError(err.message);
        setUserData(null);
      } finally {
        setLoading(false);
      }
    };
    
      getData();
    
  }, [getAddData]);


  console.log(getAddData,"getAddData")
  // delete user

  const HandleOnDelete = (id) => {
    setPopup({
      show: true,
      id,
    });
  };

  const handleDeleteTrue = async () => {
    if (popup.show && popup.id) {
      await axios.delete(`http://192.168.1.192:3000/user/${popup.id}`);

      const Deleteuserlist = userdata.filter((ele)=>ele.id !== popup.id );
      setUserData(Deleteuserlist);
      setPopup({
        show: false,
        id: null,
      });
    }
  };

  const handleDeleteFalse = () => {
    setPopup({
      show: false,
      id: null,
    });
  };

  //   const HandleOnDelete = async (id) => {
  //     console.log("userdelted", id);
  //     await axios.delete(`http://192.168.1.192:3000/user/${id}`);
  //   };


  const handleOnLogout = ()=>{
    localStorage.clear();
    toast.success("Logout succesfully",{autoClose: 500});
    setTimeout(() => {
      navigate('/');
    }, 1000);
  }


  console.log("userdata1",userdata)

  const userListData =
  userdata?.map((user,index) => {
      return (
        <>
          <tr key={index}>
            <td>{user.id}</td>
            <td>{user.name}</td>
            <td>{user.email}</td>
            <td>{user.password}</td>
            <td>{user.Address}</td>
            <td>{user.phone}</td>

            <td><img src={user.profileimage}  /></td>
            {/* <td>
              <button onClick={() => HandleOnDelete(user.id)}>Delete</button>
            </td> */}
            <td>
            <Popconfirm
              title="Are you sure Want to Delete？"
              onConfirm={handleDeleteTrue}
              onCancel={handleDeleteFalse}
            >
              <button onClick={() => HandleOnDelete(user.id)}>Delete</button>
            </Popconfirm>
            </td>
            {/* <td>
                <DeleteUser id={user.id}  />
            </td> */}
            <td><EditUser user={user} setAddData={setAddData}/></td>
          </tr>
        </>
      );
    });

  return (
    <>
      {loading && <div>A moment a sec please...</div>}
      {error && (
        <div>{`There is a problem fetching the post data - ${error}`}</div>
      )}

      <AddUser setAddData={setAddData} />

      <button className="logout-btn" onClick={handleOnLogout}>Logout</button>

      <table className="table">
        <thead>
          <tr>
            <th>id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Address</th>
            <th>PhoneNo</th>
            <th>Image</th>
            <th>Delete</th>
            
            {/* <th>Gender</th>
            <th>Qualification</th>
            <th>Hobbies</th>
            <th>Image</th>
            <th>Notification</th>
            <th>Status</th>
            <th>Delete</th>
            <th>Edit</th> */}
          </tr>
        </thead>
        <tbody>{userListData}</tbody>
      </table>
      <ToastContainer />
    </>
  );
};

export default Userdata;
