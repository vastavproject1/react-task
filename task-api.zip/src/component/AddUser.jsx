import React, { useEffect, useState } from "react";
import "./style.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Modal from "react-bootstrap/Modal";
import axios from "axios";
import FileBase64 from 'react-file-base64';

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AddUser = (props) => {
  //   model open
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    return setShow(true);
  };

  // user state

  const [AddUser, setAddUser] = useState([]);
  const [Name, setName] = useState("");
  const [EmailID, setEmailID] = useState("");
  const [Password, setPassword] = useState("");
  const [Address, setAddress] = useState("");
  const [Number, setNumber] = useState("");
  const [File,setFilename] = useState(null);

  const [err,seterr] = useState(false)

  

  const handlOnFile = (e) =>{
    setFilename(e.base64);
    
  }


  // onsubmit
  const handleOnSubmit = async (e) => {

    e.preventDefault();
 
    var User = {
      name: Name,
      email: EmailID,
      password: Password,
      Address: Address,
      phone: Number,
      profileimage:File
    };

    console.log(User,"User");
    if(Name && EmailID && Password && Address && Number && File ){
    try {
      const response = await axios.post("http://192.168.1.192:3000/user", User);
      setAddUser([...AddUser, User]);
      toast.success("user added succesfully",{autoClose: 500});
      // alert("user added");
      props.setAddData([...AddUser, User]);
      handleClose();
    } catch (err) {
      // console.log(err,);
      // alert(err);
      toast.error("something went wrong",{autoClose: 500});
    }
    // props.setAddData([User])
    setName("");
    setEmailID("");
    setPassword("");
    setAddress("");
    setNumber("");
   
    }
    if(Name.length === 0 || EmailID.length === 0 || Password.length === 0 || Address.length === 0 ||  Number.length === 0 || File === null )
      seterr(true);
      // console.log("user empty")
    ;}
    
  return (
    <>
      <div className="add-user">
        <button onClick={handleShow}>AddUser</button>
      </div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div className="form-grp">
              <label>Enter Name :</label>
              <input
                type="text"
                value={Name}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              {err && Name.length <=0?<span style={{color:"red"}}>Name is required</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter EmailID :</label>
              <input
                type="email"
                value={EmailID}
                onChange={(e) => {
                  setEmailID(e.target.value);
                }}
              />
              {err && EmailID.length <=0?<span style={{color:"red"}}>EmailID is required</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Password :</label>
              <input
                type="password"
                value={Password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
              {err && Password.length <=3 ?<span style={{color:"red"}}>Password is required at least more than 3 char</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Address :</label>
              <input
                type="textarea"
                value={Address}
                onChange={(e) => {
                  setAddress(e.target.value);
                }}
                
              />
               {err && Address.length <=0?<span style={{color:"red"}}>Address is required</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Number :</label>
              <input
                type="number"
                value={Number}
                onChange={(e) => {
                  setNumber(e.target.value);
                }}
              />
              {err && Number.length <=0?<span style={{color:"red"}}>Number is required</span>:""}
            </div>

            <div className="image-file">
            <p>Upload Image</p>
              {/* <input type="file" name="file"  onChange={handlOnFile}/> */}
              <FileBase64
              multiple={ false }
              onDone={handlOnFile} />
              {err && File === null?<span style={{color:"red"}}>file is required</span>:""}
            </div>

            <div className="form-grp submit-btn">
              <input
                type="submit"
                value="Add"
                className="add-btn"
                onClick={handleOnSubmit}
              />
              
            </div>
          </form>
        </Modal.Body>
      </Modal>
      <ToastContainer />
    </>
  );
};

export default AddUser;
