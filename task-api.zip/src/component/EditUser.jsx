import React from "react";
import Modal from "react-bootstrap/Modal";
import { useState } from "react";
import axios from "axios";
import FileBase64 from "react-file-base64";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const EditUser = (props) => {
  const [EditUser, setEditUser] = useState([]);

  const [Name, setName] = useState(props.user.name);
  const [EmailID, setEmailID] = useState(props.user.email);
  const [Password, setPassword] = useState(props.user.password);
  const [Address, setAddress] = useState(props.user.Address);
  const [Number, setNumber] = useState(props.user.phone);
  const [File, setFilename] = useState(props.user.profileimage);
  const [err,seterr] = useState(false)
  // console.log(File,"props");

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => {
    return setShow(true);
  };

  const handlOnFile = (e) => {
    setFilename(e.base64);
  };

  const handleoncloseimage = (e) => {
    e.preventDefault();
    // console.log("image deleted");
    setFilename(null);
  };

  const handleOnEdit = async (e) => {
    e.preventDefault();


    // console.log("submit" ,e)
    var User = {
      name: Name,
      email: EmailID,
      password: Password,
      Address: Address,
      phone: Number,
      profileimage: File,
    };
    console.log("User", User);

    if(Name && EmailID && Password && Address && Number &&  File )
    {
    try {
      const response = await axios.post(
        `http://192.168.1.192:3000/user/${props.user.id}`,
        User
      );
        // alert("user edited")
        toast.success("user edited succesfully",{autoClose: 500});
      // console.log(response, "imageUpload");
      props.setAddData([User]);
      console.log(response, "imageUploadComplete");
      if (response) {
        handleClose();
      }
    } catch (err) {
      // alert(err)
      toast.error("user not edited",{autoClose: 500});
    }
  };

  console.log(File,"file1")
  if(Name.length === 0 || EmailID.length === 0 || Password.length === 0 || Address.length === 0 ||  Number.length === 0  || File === null )
  {
    // console.log("show error")
  seterr(true);
  // console.log("plz fill all data")
  }

  }
  

  return (
    <>
      <button onClick={handleShow}>Edit</button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div className="form-grp">
              <label>Enter Name :</label>
              <input
                type="text"
                value={Name}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              {err && Name.length <=0?<span style={{color:"red"}}>Name is required</span>:""}
            </div>
            
            <div className="form-grp">
              <label>Enter EmailID :</label>
              <input
                type="email"
                value={EmailID}
                onChange={(e) => {
                  setEmailID(e.target.value);
                }} 
              />
              {err && EmailID.length <=0?<span style={{color:"red"}}>EmailID is required</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Password :</label>
              <input
                type="password"
                value={Password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
               {err && Password.length <=3 ?<span style={{color:"red"}}>Password is required at least more than 3 char</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Address :</label>
              <input
                type="textarea"
                value={Address}
                onChange={(e) => {
                  setAddress(e.target.value);
                }}
              />
              {err && Address.length <=0?<span style={{color:"red"}}>Address is required</span>:""}
            </div>
            <div className="form-grp">
              <label>Enter Number :</label>
              <input
                type="number"
                value={Number}
                onChange={(e) => {
                  setNumber(e.target.value);
                }}
              />
              {err && Number.length <=0?<span style={{color:"red"}}>Number is required</span>:""}
            </div>
            <div className="image-file">
              {File ? (
                <>
                  <p>Profile</p>
                  <button onClick={handleoncloseimage} className="close-icon">
                    X
                  </button>
                </>
              ) : (
                  <>
                    <p>Re-upload Profile</p>
                  <FileBase64
                    value={File}
                    multiple={false}
                    onDone={handlOnFile}
                  />
                  {console.log(File,"Fileedit")}
                  {err && File === null?<span style={{color:"red"}}>file is required</span>:""}
                </>
              )}
              <img src={File} />
             
              
            </div>
            <div className="form-grp submit-btn">
              <input
                type="submit"
                value="Edit"
                className="add-btn"
                onClick={handleOnEdit}
              />
            </div>
          </form>
        </Modal.Body>
      </Modal>
      <ToastContainer />
    </>
  );
};

export default EditUser;
