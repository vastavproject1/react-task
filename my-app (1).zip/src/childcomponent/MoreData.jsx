import React from 'react'
import "../style.css";

const MoreData = (props) => {
    const lcldata = props.user.map((e) => {
        return (
          <>
            <tr>
              <td>{e.userid}</td>
              <td>{e.name}</td>
              <td>{e.Email}</td>
              <td>{e.Password}</td>
              <td>{e.Address}</td>
              <td>{e.PhoneNo}</td>
              <td>{e.Gender}</td>
              <td>{e.Qualification + " "}</td>
            <td>{e.Hobbies + " "}</td>
            <td><img src={e.Files} alt="" /></td>
              {/* <td><img src={e.Files} /></td> */}
            </tr>
            </>
              );
              });
              
  return (
    <div>
       <>
       <h5>More Details</h5>
       <table className="table">
       <thead>
          <tr>
            <th>id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Address</th>
            <th>PhoneNo</th>
            <th>Gender</th>
            <th>Qualification</th>
            <th>Hobbies</th>
            <th>Image</th>
          </tr>
        </thead>
        <tbody>
            {lcldata}
        </tbody>
       </table>
       
       </>
    </div>
  )
  }
export default MoreData