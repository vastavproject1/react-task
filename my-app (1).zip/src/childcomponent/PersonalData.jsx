import React from 'react'
import "../style.css";
const PersonalData = (props) => {
    const lcldata = props.user.map((e) => {
        return (
          <>
            <tr>
              <td>{e.userid}</td>
              <td>{e.name}</td>
              <td>{e.Email}</td>
              <td>{e.Password}</td>
              <td>{e.Address}</td>
              <td>{e.PhoneNo}</td>
              <td>{e.Gender}</td>
              {/* <td><img src={e.Files} /></td> */}
            </tr>
            </>
              );
              });
              
  return (
    <div>
       <>
       <h5>Personal Details</h5>
       <table className="table">
       <thead>
          <tr>
            <th>id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Address</th>
            <th>PhoneNo</th>
            <th>Gender</th>
          </tr>
        </thead>
        <tbody>
            {lcldata}
        </tbody>
       </table>
       
       </>
    </div>
  )
}

export default PersonalData