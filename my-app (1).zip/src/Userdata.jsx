import React, { useEffect, useState } from "react";
import data from "./data.json";
import "./style.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import Select from "react-select";
import FileBase64 from 'react-file-base64';
import { useNavigate } from 'react-router-dom';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { Popconfirm } from 'antd';
import 'antd/dist/antd.css';
import Switch from "react-switch";

import MoreData from "./childcomponent/MoreData";
import PersonalData from "./childcomponent/PersonalData";


const getdata = () => {
  const newData = localStorage.getItem("user");
  if (newData) {
    return JSON.parse(newData);
  } else {
    return localStorage.setItem("user", JSON.stringify(data));
    // return [];

  }
};



function Userdata() {
  const navigate = useNavigate();
// useEffect(()=>{
// if(localStorage.getItem("useLogin")){
//   navigate("/userdata");
//   // console.log("have data");
// }
// },[])

  // localStorage.setItem("user", JSON.stringify(data));


  const [show, setShow] = useState(false);
  const [user, setuser] = useState(getdata());

  const [edittoggle, setedittoggle] = useState(true);
  const [edtitemid, setedtitemid] = useState(null);

  const [userid, setuserid] = useState();
  const [name, setName] = useState("");
  const [Email, setEmail] = useState("");
  const [Password, setPassword] = useState("");
  const [Address, setAddress] = useState("");
  const [PhoneNo, setPhoneNo] = useState("");
  // const [Gender, setGender] = useState("");
  const [Qualification, setQualification] = useState([]);
  const [Hobbies, setHobbies] = useState();
  const [Files, setFiles] = useState();

  const [popup, setPopup] = useState({
    show: false, // initial values set to false and null
    id: null,
  });

  // const [newgender,setnewgender] = useState("male");
  const [Gender,setGender] = useState("male");

  useEffect(()=>{
    setuserid(user.length+1)
  },[user])

  var Hobbiesdata = [
    {
      value: 1,
      label: "cricket",
    },
    {
      value: 2,
      label: "vollyball",
    },
    {
      value: 3,
      label: "football",
    },
    {
      value: 4,
      label: "tenis",
    },
  ];

  let gender = ["male","female","other"];

  // useEffect(() => {
  //   // console.log("ddddddddd");
  //   // getdata();
  //   // (JSON.parse(localStorage.getItem('userobject')));
  //   // localStorage.setItem("user", JSON.stringify(user));
  //   // localStorage.setItem("user", JSON.stringify(data));
  //   // localStorage.setItem("user", JSON.stringify(data));
  // }, []);

  // const handleOnUserid = (e) => {
  //   setuserid(e.target.value);
  // };
  const handleOnName = (e) => {
    setName(e.target.value);
  };
  const handleOnEmail = (e) => {
    setEmail(e.target.value);
  };
  const handleOnPassword = (e) => {
    setPassword(e.target.value);
  };

  const handleOnAddress = (e) => {
    setAddress(e.target.value);
  };

  const handleOnPhoneNo = (e) => {
    setPhoneNo(e.target.value);
  };

  // const handelOnGender = (e) => {
  //   setGender(e.target.value);
  // };

  const handleOnQualification = (e) => {
    // setQualification([...Qualification, e.target.value]);
  
    const {value , checked} = e.target;

     console.log("value",value)
     console.log("checked",checked)

    if(checked){
      setQualification([...Qualification, value]);
    }
    else{
      setQualification(Qualification.filter((e)=> e !== value ))
    }
    // console.log({value},{checked});
    // setQualification(Array.isArray(e)?e.map(x=>x.label):[]);
  };

  // console.log(Qualification,"qualification");
  const handleOnHobbies = (e) => {
    setHobbies(Array.isArray(e) ? e.map((x) => x.label) : []);
    // setHobbies([...Hobbies,e.target.value]);
  };

  const handlOnFile =(e) =>{
    // console.log(e.base64);
    setFiles(e.base64);
  }

  const handleOnLogout = (e) =>{
    // console.log("logout")
    localStorage.clear();
    navigate('/');
  }


  // const deleteuser = (id) => {

  //   console.log(id);
  //   localStorage.removeItem(id);
  //   const deletefilteruser = user.filter((ele, index) => {
  //     return ele.userid !== id;
  //   });
  //   // console.log(deletefilteruser);

  //   setuser(deletefilteruser);
  //   // localStorage.removeItem(deletefilteruser);
  // };

  const deleteuser = (id) => {
    // console.log(id);
    setPopup({
        show:true,
        id
      }
    );
   
  };
  // console.log(popup);

  const handleDeleteTrue = () => {
    if (popup.show && popup.id) {
      // const deletefilteruser = user.filter((ele, index) => {
      //       return ele.userid !== id;
      let deletefilteruser = user.filter((ele) => ele.userid !== popup.id);
      setuser(deletefilteruser);
      setPopup({
        show: false,
        id: null,
      });
    }
};

  const handleDeleteFalse = () => {
    setPopup({
      show: false,
      id: null,
    });
  };


  const edituser = (id) => {
    // console.log(id);
    // if(id){
    handleShow();

    const editfilteruser = user.find((ele) => {
      return ele.userid === id;
    });

    setuserid(editfilteruser.userid);
    setName(editfilteruser.name);
    setEmail(editfilteruser.Email);
    setPassword(editfilteruser.Password);
    setAddress(editfilteruser.Address);
    setPhoneNo(editfilteruser.PhoneNo);
    setGender(editfilteruser.Gender);
    setQualification(editfilteruser.Qualification);
    // console.log(editfilteruser.Qualification,"gjls");
    setFiles(editfilteruser.Files);
    setHobbies(editfilteruser.Hobbies);
    // console.log(editfilteruser.Hobbies,"hobies");
    setedittoggle(false);
    setedtitemid(id);
    // }
    // else{
    //   setName('');
    // }
  };

  const handleRegister = (e) => {

    // console.log(user.length);
    // setuserid(5);

    e.preventDefault();
    var User = {
      userid,
      name,
      Email,
      Password,
      Address,
      PhoneNo,
      Gender,
      Qualification,
      Hobbies,
      Files,
      // newgender
    };

    // console.log("useer",user.length+1);

    if (!userid && !name && !Email && !Password && !Address && !PhoneNo) {
      alert("plz fill data");
    } 
    else if (
      userid &&
      name &&
      Email &&
      Password &&
      Address &&
      PhoneNo &&
      !edittoggle
    ) {
      setuser(
        user.map((ele) => {
          if (ele.userid === edtitemid) {
            return {
              ...ele,
              name: name,
              Email: Email,
              Password: Password,
              Address: Address,
              PhoneNo: PhoneNo,
              Gender: Gender,
              Qualification: Qualification,
              Hobbies: Hobbies,
              Files:Files,
              // newgender:newgender
            };
          }
          return ele;
          //  return localStorage.setItem("user", JSON.stringify(ele));
        })
      );
      // localStorage.setItem("user", JSON.stringify(user));
      // console.log(Qualification);
      handleClose();
    } else {
      setuser([...user, User]);
      // console.log([...user, User]);
      const arr = [...user, User];
      localStorage.setItem("user", JSON.stringify(arr));
      setuserid("");
      setName("");
      setEmail("");
      setPassword("");
      setAddress("");
      setPhoneNo("");
      setGender("");
      setQualification("")

      handleClose();
      
    }
  };

  const handleClose = () => setShow(false);
  const handleShow = () => { 
    setName("");
    setEmail("");
    setPassword("");
    setAddress("");
    setPhoneNo("");
    setGender("");
    setQualification("");
    setedittoggle(true);
    setShow(true)
  };
 

  const lcldata = user.map((user) => {
    return (
      <>
        {/* <h1>{info.Email}</h1>
         */}
        {/* { data.push(JSON.parse(localStorage.getItem('userobject')))} */}
        <tr key={user.userid}>
          <td>{user.userid}</td>
          <td>{user.name}</td>
          <td>{user.Email}</td>
          <td>{user.Password}</td>
          <td>{user.Address}</td>
          <td>{user.PhoneNo}</td>
          <td>{user.Gender}</td>
          <td>{user.Qualification + " "}</td>
          <td>{user.Hobbies + " "}</td>
          <td><img src={user.Files} alt="" /></td>
          <td>{user.Notification}</td>
          <td>{user.Status}</td>
          {/* <td>{user.newgender}</td> */}

          {/* <td onClick={() => deleteuser(user.userid)}><button>Delete</button></td> */}
          <td >
          <Popconfirm
            title="Are you sure Want to Delete？"
            icon={
              <QuestionCircleOutlined
                style={{
                  color: 'red',
                }}
              />
            }
            onConfirm={handleDeleteTrue}
            onCancel={handleDeleteFalse}  
          >
              <button onClick={() => deleteuser(user.userid)}>Delete</button>
              {/* <td onClick={() => deleteuser(user.userid)}><button>Delete</button></td> */}

          </Popconfirm>
          </td>
          {/* <td onClick={() => edituser(user.userid)}><button>Edit</button></td> */}
          <td><button  onClick={() => edituser(user.userid)}>Edit</button></td>
        </tr>
      </>
    );
  });

  return (
    <>

  

    <div className="user-area">
    <button onClick={handleShow}>Add User</button>
    <button className="logout" onClick={handleOnLogout}>Logout</button>
    </div>
      <table className="table">
        <thead>
          <tr>
            <th>id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Address</th>
            <th>PhoneNo</th>
            <th>Gender</th>
            <th>Qualification</th>
            <th>Hobbies</th>
            <th>Image</th>
            <th>Notification</th>
            <th>Status</th>
            <th>Delete</th>
          
            <th>Edit</th>

          </tr>
        </thead>
        <tbody>
          {lcldata}


        </tbody>
      </table>
      
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          
          {edittoggle?<Modal.Title>Add User</Modal.Title>:<Modal.Title>Edit User</Modal.Title>}
          
        </Modal.Header>
        <Modal.Body>
          <form>
            {/* <input
              type="number"
              placeholder="Enter your userid"
              value={userid}
              onChange={handleOnUserid}
              className="form-control"
            /> */}
            <input
              type="text"
              placeholder="Enter your Name"
              value={name}
              onChange={handleOnName}
              className="form-control"
            />
            <input
              type="email"
              placeholder="Enter your Email"
              value={Email}
              onChange={handleOnEmail}
              className="form-control"
            />
            <input
              type="password"
              placeholder="Enter your Password"
              value={Password}
              onChange={handleOnPassword}
              className="form-control"
            />
            <input
              type="text"
              placeholder="Enter your Address"
              value={Address}
              onChange={handleOnAddress}
              className="form-control"
            />
            <input
              type="number"
              placeholder="Enter your PhoneNo"
              value={PhoneNo}
              onChange={handleOnPhoneNo}
              className="form-control"
            />
            <label>Please Select Gender</label><br/>
            {
                gender.map(result=>(
                  <>
                   <input type="radio" id={result} value={result} checked={Gender===result} name="gender"onChange={(e)=>setGender(e.target.value)}/>

                    <label className="gender-label" htmlFor={result}>{result}</label>
                  </>
                ))
              }
            {/* <div className="gender-flex">
              <input
                type="radio"
                value="male"
                id="male"
                name="gender"
                
                onChange={handelOnGender}
              />
              <label htmlFor="male" className="male_label">
                Male
              </label>
              <input
                type="radio"
                value="female"
                id="femail"
                name="gender"
                onChange={handelOnGender}
              />
              <label htmlFor="female">Female</label>
            </div> */}

            <div className="qualification">
              <p>Select Qualification</p>
              <input
                type="checkbox"
                value="BE"
                name="be"
                id="be"
                className="gender-label"
                onChange={handleOnQualification}
                defaultChecked = {Qualification.includes("BE")}
              
               />
              <label htmlFor="be">BE</label>
              <input
                type="checkbox"
                value="DIPLOMA"
                name="diploma"
                className="gender-label"
                onChange={handleOnQualification}
                defaultChecked = {Qualification.includes("DIPLOMA")}
                id="diploma"
              />
              <label htmlFor="diploma">DIPLOMA</label>
              <input
                type="checkbox"
                value="BCA"
                name="bca"
                className="gender-label"
                onChange={handleOnQualification}
                defaultChecked = {Qualification.includes("BCA")}
                id="bca"
              />
              <label htmlFor="bca">BCA</label>
              <input
                type="checkbox"
                value="MCA"
                name="mca"
                className="gender-label"
                onChange={handleOnQualification}
                defaultChecked = {Qualification.includes("MCA")}
                id="mca"
              />
              <label htmlFor="mca">MCA</label>
            </div>
            <div className="hobbies">
              <p>please select hobbies</p>
              <Select
                isMulti
                options={Hobbiesdata}
                onChange={handleOnHobbies}
                // defaultInputValue={Hobbies}
                defaultInputValue={Hobbies}
                hideSelectedOptions={false}
                // defaultValue={Hobbiesdata}
                defaultChecked = {Qualification.includes("BE")}
              ></Select>
            </div>
            
            <div className="image-file">
            <p>Upload Image</p>
             {/* <input type="file" onChange={handlOnFile} />
              */}
              <FileBase64
              multiple={ false }
              onDone={handlOnFile}
              // value={Files}
               />
              </div>
              <br/>

              <label>
                <span>Notificaton</span>
              <Switch  draggable ={false  } />
              </label>
              <label>
                <span>Status</span>
              <Switch  />
              </label>

            {edittoggle ? (
              <input
                type="submit"
                value="Add"
                className="form-control"
                onClick={handleRegister}
              />
            ) : (
              <input
                type="submit"
                value="Edit"
                className="form-control"
                onClick={handleRegister}
              />
            )}
          </form>
        </Modal.Body>
      </Modal>
      {/* {console.log(edtitemid)}
       */}
      {/* <h5>{edtitemid}</h5> */}
      
      
    <PersonalData user={user}/>
    <MoreData  user={user}/>
      
    </>
  );
}

export default Userdata;
