import React, { useState,useEffect } from 'react';
import data from './data.json'
import './style.css';
import {
    Route,
    Routes,
    Navigate,
    useNavigate
  } from 'react-router-dom'
  
    

function Login(){
    const navigate = useNavigate();
   
    useEffect(()=>{
    if(localStorage.getItem("useLogin")){
      navigate("/userdata");
      // console.log("have data");
    }
    },[])



    const[email,setEmail] = useState("");
    const[password,setPassword] = useState();
    // const[address,setaddress] = useState();

    // const jsondata = data.map((info)=>{
    //     return(
    //         <>
    //             {info.Email}
                
    //             {/* {console.log(jsondata)} */}
    //         </>    
    //     )
    // }
    // )



    const handleOnEmail=(e)=>{
        setEmail(e.target.value);
        
    }
  
    const handleOnPass=(e)=>{
        setPassword(e.target.value);
    }
    const handleLogin=(e)=>{ 
        

        e.preventDefault();
        // const emailfilter = data.filter(item=> item.Email.includes(email) && item.Password.includes(password));
       
        const emailfilter = data.filter(obj => obj.Email == email && obj.Password == password);
        // console.log(emailfilter);
        // console.log(emailfilter.length);
        if(emailfilter.length > 0 ){

            alert("login successfully");
            // console.log(emailfilter[]);
            // localStorage.setItem("user", JSON.stringify(emailfilter));
            localStorage.setItem("useLogin", JSON.stringify(emailfilter[0]));
            navigate("/userdata")
            // Navigate("/userdata");
            // useNavigate('Userdata')
        }else if(!email && !password){
            alert("pls enter email and password");
        } 
        else if(password.length < 3){
            alert("password must be 6 character");
        }
        else{
            alert("login faild");
        }
        
    }


    return (
        <>
            <h1>Login page</h1>
            <div className='login-form'>
            <form>
            <input type="email" placeholder='email'  value={email} className='form-control' onChange={handleOnEmail}/>
            {/* <input type="text" placeholder='adress'  value={address} className='form-control' onChange={handleOnAddress}/> */}
            <input type="password" placeholder='password' value={password} className='form-control'onChange={handleOnPass} />
            <input type="submit" value="submit" className='form-control' onClick={handleLogin}/>
           
            </form>
            {/* <h1>{data.Email}</h1> */}
            </div>
            {/* {jsondata} */}
            {/* {console.log({jsondata})} */}
        </>
    )
}

export default Login;