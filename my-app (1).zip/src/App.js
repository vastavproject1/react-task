import Login from "./Login";
// import React, { useEffect, useState } from "react";
import logo from "./logo.svg";
import Userdata from "./Userdata";
import "./App.css";
import {
  Route,
  Routes,
  Navigate,
  useNavigate,
  BrowserRouter,
} from "react-router-dom";
import Protected from './Protected'

function App() {


  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />

          <Route
            path="/userdata"
            element={
              // <PrivateRoute>
                <Protected Cmp ={Userdata} />
                // <Userdata />
              // </PrivateRoute>
            }
          />
        </Routes>
      </BrowserRouter>
      {/* <button onClick={protectedRoute}>hi</button> */}
    </div>
  );
}
export default App;
